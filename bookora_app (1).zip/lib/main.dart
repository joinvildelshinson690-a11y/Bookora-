import 'package:flutter/material.dart';

void main() {
  runApp(const BookoraApp());
}

class BookoraApp extends StatelessWidget {
  const BookoraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Bookora',
      theme: ThemeData(
        primarySwatch: Colors.indigo,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.book, size: 90),
            SizedBox(height: 20),
            Text('Welcome to Bookora', style: TextStyle(fontSize: 24)),
          ],
        ),
      ),
    );
  }
}
